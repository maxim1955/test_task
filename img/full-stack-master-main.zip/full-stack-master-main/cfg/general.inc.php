<?php

// db
const DB_HOST = '127.0.0.1';
const DB_USER = 'root';
const DB_PASS = 'root';
const DB_NAME = 'test';
// common
const SITE_SCHEME = 'http';
const DEFAULT_TIMEZONE = '240';
const LOGIN_ATTEMPTS = '15';
